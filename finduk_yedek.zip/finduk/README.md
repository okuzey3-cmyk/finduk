# Finduk
ESP32-S3 sesli asistan robot. sketch/ = Arduino kodu (anahtarlari kendin yaz), stl/ = 3D baski, cad/ = parametrik tasarim kodu.
